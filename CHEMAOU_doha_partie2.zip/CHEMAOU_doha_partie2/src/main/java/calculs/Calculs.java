package calculs;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Scanner;

import com.github.andrewoma.dexx.collection.HashMap;

import org.eclipse.rdf4j.query.algebra.StatementPattern;

public class Calculs {
    public static Hashtable<Integer, Integer> numCond_numQuery = new Hashtable<>();
    public static List<String> queries = new ArrayList<>();
    public static Hashtable<Integer,Integer> doublons = new Hashtable<>();
    public static int requetes = 0;
    
}
