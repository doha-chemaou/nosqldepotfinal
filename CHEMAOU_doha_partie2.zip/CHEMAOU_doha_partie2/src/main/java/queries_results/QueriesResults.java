package queries_results;
import indexation.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


import dictionnaire.*;

public class QueriesResults {
    public static List<String> branches = new ArrayList<>();
    static List<Long> keys = new ArrayList<>();
    public static List<Long> subjects = new ArrayList<>();
    public static List<Long> common_subjects = new ArrayList<>();
    public static String results = "";
    public static String result = "";
    public static int c = 0 ; 

    static public void results_(String query_){
        int k = 0;
        List<String> subject = new ArrayList<>();

        List<String> subject_ = new ArrayList<>();
        List<String> subject_common = new ArrayList<>();
        
        for (k = 0 ; k < branches.size(); k+=2){
            if(k==0){
                if(Indexation.po_s.get(branches.get(k)+"_"+branches.get(k+1))!=null){
                    subject = Indexation.po_s.get(branches.get(k)+"_"+branches.get(k+1));
                }
            }
            else{
                subject_ = Indexation.po_s.get(branches.get(k)+"_"+branches.get(k+1));
                if(subject_!=null){
                    for (int i = 0 ; i < subject.size(); i++){
                        if(subject_.contains(subject.get(i))){
                            subject_common.add(subject.get(i));
                        }
                    }
                    subject = subject_common;
                    subject_common=new ArrayList<>();
                }
                else{
                    subject = new ArrayList<>();
                }
                
                if(subject.isEmpty()) k = branches.size();
            }
        }
        c +=(subject.size()==0?0:1);
    }

    static public void results (String query_){
       
            keys = new ArrayList<>();
            subjects = new ArrayList<>();
            common_subjects = new ArrayList<>();
            for (int i = 0 ; i < branches.size();i++){
                Long key = Dictionnaire.getResource_key().get(branches.get(i));
                keys.add(key);
            }
            int k;
            for (k = 0 ; k < keys.size(); k+=2){
                for(int i = 0 ; i < POS.getTriplets().size() ; i++){
                    Long predicate = Dictionnaire.getResource_key().get(POS.getTriplets().get(i).get(0));
                    Long object = Dictionnaire.getResource_key().get(POS.getTriplets().get(i).get(1));
                    Long subject = Dictionnaire.getResource_key().get(POS.getTriplets().get(i).get(2));

                    if(keys.get(k)==predicate && keys.get(k+1)==object){
                        if(k == 0){
                            if(!subjects.contains(subject))
                                subjects.add(subject);
                        }
                        else{
                            if(subjects.contains(subject) && !common_subjects.contains(subject)){
                                common_subjects.add(subject);
                            }
                        }
                    }
                }
                if(k!=0){
                    subjects = common_subjects;
                    common_subjects = new ArrayList<>();
                }
                
                if(subjects.isEmpty()) k = keys.size();
            }
 
            String a = "```PAS DE RESULTATS```";
            results +=  query_ +"\n----> Resultats : "+(subjects.size()==0?a:"")+"\n";//+"Resultats : \n";
            for(int i = 0 ; i < subjects.size();i++){
                result = Dictionnaire.key_resource.get(subjects.get(i));
                results+= result +"\n";
            }
            results+="\n----------------------------------------------\n";
   
}

    public static void writes_into_file(String contenu,String path){
        try {

            BufferedWriter fWriter = new BufferedWriter(new FileWriter(path));
            fWriter.write(contenu);
            fWriter.close();
    }

        catch (IOException e) {
            System.out.print(e.getMessage());
    }

    }

    public static void all(String query_){
        results_(query_);
        writes_into_file(results,"C:\\mes_dossiers\\S3\\914 - noSQL\\CHEMAOU_doha_squelette_projet\\src\\main\\java\\queries_results\\results.md");

    }
}

