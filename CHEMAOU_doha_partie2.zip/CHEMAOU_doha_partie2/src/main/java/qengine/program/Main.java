

package qengine.program;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

import java.util.HashMap;
import java.util.Hashtable;

import com.github.jsonldjava.shaded.com.google.common.collect.HashBiMap;


import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.eclipse.rdf4j.query.algebra.StatementPattern;
import org.eclipse.rdf4j.query.algebra.helpers.StatementPatternCollector;
import org.eclipse.rdf4j.query.parser.ParsedQuery;
import org.eclipse.rdf4j.query.parser.sparql.SPARQLParser;
import org.eclipse.rdf4j.rio.RDFFormat;
import org.eclipse.rdf4j.rio.RDFParser;
import org.eclipse.rdf4j.rio.Rio;


import dictionnaire.Dictionnaire;
import indexation.*;
import queries_results.*;
import calculs.Calculs;

/**
 * Programme simple lisant un fichier de requête et un fichier de données.
 * 
 * <p>
 * Les entrées sont données ici de manière statique, à vous de programmer les
 * entrées par passage d'arguments en ligne de commande comme demandé dans
 * l'énoncé.
 * </p>
 * 
 * <p>
 * Le présent programme se contente de vous montrer la voie pour lire les
 * triples et requêtes depuis les fichiers ; ce sera à vous d'adapter/réécrire
 * le code pour finalement utiliser les requêtes et interroger les données. On
 * ne s'attend pas forcémment à ce que vous gardiez la même structure de code,
 * vous pouvez tout réécrire.
 * </p>
 * 
 * @author Olivier Rodriguez <olivier.rodriguez1@umontpellier.fr>
 * @author CHEMAOU Doha
 */

final class Main {
	static final String baseURI = null;

	
	// Votre répertoire de travail où vont se trouver les fichiers à lire
	
	static final String workingDir = "data/";
	
	 // Fichier contenant les requêtes sparql
	 
	// static final String queryFile = workingDir + "sample_query.queryset";

	static String queryFile = workingDir + "";

	// Fichier contenant des données rdf
	 
	// static final String dataFile = workingDir + "100K.nt";

	static String dataFile = workingDir + "";

	static String outputFile = workingDir + "";

	int cpt = 0;

	public static String getDataFile(){ return dataFile;}

	// ========================================================================

	
	 // Méthode utilisée ici lors du parsing de requête sparql pour agir sur l'objet obtenu.
	 
	public static void processAQuery(ParsedQuery query,String query_) {
		List<StatementPattern> patterns = StatementPatternCollector.process(query.getTupleExpr());
		for (int i = 0 ;i < patterns.size();i++){
			String predicate = patterns.get(i).getPredicateVar().getValue().toString();
			String object = patterns.get(i).getObjectVar().getValue().toString();
			QueriesResults.branches.add(predicate);
			QueriesResults.branches.add(object);
		}
		QueriesResults.all(query_);
		QueriesResults.branches = new ArrayList<>();
		
	}

	
	// Entrée du programme
	 
	public static void main(String[] args) throws Exception {

		final Options options = configParameters();
		final CommandLineParser parser = new DefaultParser();
		final CommandLine line = parser.parse(options, args);

		boolean helpMode = line.hasOption("help"); // args.length == 0
		if (helpMode) {
			final HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("RDFEngine", options, true);
			System.exit(0);
		}

		dataFile = line.getOptionValue("data", workingDir + "500K.rdf");
		outputFile = line.getOptionValue("output", workingDir + "output.txt");
		String dir = "data/1000";
		Calculs.requetes = 0;
		Calculs.queries = new ArrayList<>();
		Calculs.doublons = new Hashtable<>();
		Calculs.numCond_numQuery = new Hashtable<>();
		Dictionnaire.key_resource = HashBiMap.create();
		Dictionnaire.resource_key = HashBiMap.create();
		Dictionnaire.subjects = new ArrayList<>();
		Dictionnaire.objects = new ArrayList<>(); 
		Dictionnaire.predicates = new ArrayList<>();
		Indexation.triplets = new ArrayList<>();
		Indexation.indexations = new HashMap<>();
		Indexation.po_s = new HashMap<>(); 
			
		parseData();

		Boolean b = dataFile.toString().equals(workingDir+"sample_data.nt");
		long start = System.nanoTime(); 
		new POS().pos(b);
		long end = System.nanoTime();
		long exec = end - start;
		double inSeconds = (double)exec / 1_000_000_000.0;
		System.out.println("\n---> POS indexation calculated in "+exec+" nanoseconds that is "+inSeconds+" seconds to execute including creation of dictionary and POS indexation and queries results\n");

		System.out.println("-------------------------");
		start = System.nanoTime();

		for (final File fileEntry : new File(dir).listFiles()) {
			System.out.println("_____________________ " +fileEntry);
			
			QueriesResults.branches = new ArrayList<>();
			QueriesResults.subjects = new ArrayList<>();
			QueriesResults.common_subjects = new ArrayList<>();
    		queryFile = line.getOptionValue("queries", fileEntry.toString());//"");   sample_query.queryset STAR_ALL_workload
			parseQueries();
	}
		end = System.nanoTime();
		exec = end - start;
		inSeconds = (double)exec / 1_000_000_000.0;
		System.out.println("\n---> Response to all queries took : "+ exec + " nanoseconds which is "+inSeconds+" in seconds");

	}

	// ========================================================================

	
	 // Traite chaque requête lue dans {@link #queryFile} avec {@link #processAQuery(ParsedQuery)}.
	 
	private static void parseQueries() throws FileNotFoundException, IOException {
		
		 
		long start = System.nanoTime(); 
		try (Stream<String> lineStream = Files.lines(Paths.get(queryFile))) {
			SPARQLParser sparqlParser = new SPARQLParser();
			Iterator<String> lineIterator = lineStream.iterator();

			StringBuilder queryString = new StringBuilder();
			int counter = 0; 

			while (lineIterator.hasNext())			 
			{
				String line = lineIterator.next();
				if(line.contains("?v0") && line.contains("<"))
					counter++;
				queryString.append(line+"\n");//.trim();
				if (line.trim().endsWith("}")) {
					
					if(Calculs.numCond_numQuery.get(counter)==null){
						Calculs.numCond_numQuery.put(counter,1);
					}
					else{
						int previous = Calculs.numCond_numQuery.get(counter);
						previous++;
						Calculs.numCond_numQuery.put(counter,previous);
					}
					Calculs.requetes++;
					ParsedQuery query = sparqlParser.parseQuery(queryString.toString(), baseURI);
					if(Calculs.queries.contains(queryString.toString())){
						if(Calculs.doublons.get(counter)==null){
							Calculs.doublons.put(counter,1);
						}
						else{
							int previous = Calculs.doublons.get(counter);
							previous++;
							Calculs.doublons.put(counter,previous);
						}
					}
					else{
						Calculs.queries.add(queryString.toString());
					}
					
					processAQuery(query,queryString.toString()); // Traitement de la requête, à adapter/réécrire pour votre programme
					queryString.setLength(0); // Reset le buffer de la requête en chaine vide
					counter=0;
				}
			}
		}
		long end = System.nanoTime();
		long exec = end - start;
		double inSeconds = (double)exec / 1_000_000_000.0;
		System.out.println("\n---> Queries results calculated in "+exec+" nanoseconds that is "+inSeconds+" seconds to execute.\n");
	}
	
	
	//  Traite chaque triple lu dans {@link #dataFile} avec {@link MainRDFHandler}.
	 
	private static void parseData() throws FileNotFoundException, IOException {

		try (Reader dataReader = new FileReader(dataFile)) {
			// On va parser des données au format ntriples
			RDFParser rdfParser = Rio.createParser(RDFFormat.NTRIPLES);

			// On utilise notre implémentation de handler
			rdfParser.setRDFHandler(new MainRDFHandler());

			// Parsing et traitement de chaque triple par le handler
			rdfParser.parse(dataReader, baseURI);
			
			Dictionnaire.displaying_dictionary(dataFile);
		}
	}

	private static Options configParameters() {

		final Option helpFileOption = Option.builder("h").longOpt("help").desc("affiche le menu d'aide").build();

		final Option queriesOption = Option.builder("queries").longOpt("queries").hasArg(true)
				.argName("/chemin/vers/dossier/requetes").desc("Le chemin vers les queries").required(false).build();

		final Option dataOption = Option.builder("data").longOpt("data").hasArg(true)
				.argName("/chemin/vers/fichier/donnees").desc("Le chemin vers les donnees").required(false).build();

		final Option outputOption = Option.builder("output").longOpt("output").hasArg(true)
				.argName("/chemin/vers/dossier/sortie").desc("Le chemin vers le dossier de sortie").required(false)
				.build();

		// crée une liste d'options
		final Options options = new Options();
		options.addOption(queriesOption);
		options.addOption(dataOption);
		options.addOption(outputOption);
		options.addOption(helpFileOption);

		return options;
	}
}
