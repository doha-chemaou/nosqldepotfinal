

package qengine.program;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.eclipse.rdf4j.query.algebra.StatementPattern;
import org.eclipse.rdf4j.query.algebra.helpers.StatementPatternCollector;
import org.eclipse.rdf4j.query.parser.ParsedQuery;
import org.eclipse.rdf4j.query.parser.sparql.SPARQLParser;
import org.eclipse.rdf4j.rio.RDFFormat;
import org.eclipse.rdf4j.rio.RDFParser;
import org.eclipse.rdf4j.rio.Rio;


import dictionnaire.Dictionnaire;
import indexation.*;
import queries_results.*;

/**
 * Programme simple lisant un fichier de requête et un fichier de données.
 * 
 * <p>
 * Les entrées sont données ici de manière statique, à vous de programmer les
 * entrées par passage d'arguments en ligne de commande comme demandé dans
 * l'énoncé.
 * </p>
 * 
 * <p>
 * Le présent programme se contente de vous montrer la voie pour lire les
 * triples et requêtes depuis les fichiers ; ce sera à vous d'adapter/réécrire
 * le code pour finalement utiliser les requêtes et interroger les données. On
 * ne s'attend pas forcémment à ce que vous gardiez la même structure de code,
 * vous pouvez tout réécrire.
 * </p>
 * 
 * @author Olivier Rodriguez <olivier.rodriguez1@umontpellier.fr>
 * @author CHEMAOU Doha
 */

final class Main {
	static final String baseURI = null;

	
	// Votre répertoire de travail où vont se trouver les fichiers à lire
	
	static final String workingDir = "data/";
	
	 // Fichier contenant les requêtes sparql
	 
	// static final String queryFile = workingDir + "sample_query.queryset";

	static String queryFile = workingDir + "";

	// Fichier contenant des données rdf
	 
	// static final String dataFile = workingDir + "100K.nt";

	static String dataFile = workingDir + "";

	static String outputFile = workingDir + "";

	int cpt = 0;

	public static String getDataFile(){ return dataFile;}

	// ========================================================================

	
	 // Méthode utilisée ici lors du parsing de requête sparql pour agir sur l'objet obtenu.
	 
	public static void processAQuery(ParsedQuery query,String query_) {
		List<StatementPattern> patterns = StatementPatternCollector.process(query.getTupleExpr());
		for (int i = 0 ;i < patterns.size();i++){
			String predicate = patterns.get(i).getPredicateVar().getValue().toString();
			String object = patterns.get(i).getObjectVar().getValue().toString();
			
			QueriesResults.branches.add(predicate);
			QueriesResults.branches.add(object);
		}
		
		QueriesResults.all(query_);
		QueriesResults.branches = new ArrayList<>();
		
	}

	
	// Entrée du programme
	 
	public static void main(String[] args) throws Exception {

		final Options options = configParameters();
		final CommandLineParser parser = new DefaultParser();
		final CommandLine line = parser.parse(options, args);

		boolean helpMode = line.hasOption("help"); // args.length == 0
		if (helpMode) {
			final HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("RDFEngine", options, true);
			System.exit(0);
		}

		dataFile = line.getOptionValue("data", workingDir + "sample_data.nt");
		outputFile = line.getOptionValue("output", workingDir + "output.txt");
		queryFile = line.getOptionValue("queries", workingDir + "STAR_ALL_workload.queryset");//"");   sample_query.queryset STAR_ALL_workload
			
		parseData();

		Boolean b = dataFile.toString().equals(workingDir+"sample_data.nt");
		long start = System.nanoTime(); 
		new SPO().spo(b);
		new SOP().sop(b);
		new OPS().ops(b);
		new OSP().osp(b);
		new PSO().pso(b);
		new POS().pos(b);
		long end = System.nanoTime();
		long exec = end - start;
		double inSeconds = (double)exec / 1_000_000_000.0;
		System.out.println("\n---> All indexations calculated in "+exec+" nanoseconds that is "+inSeconds+" seconds to execute\n");

		System.out.println("-------------------------");
		start = System.nanoTime();

			
		QueriesResults.branches = new ArrayList<>();
		QueriesResults.subjects = new ArrayList<>();
		QueriesResults.common_subjects = new ArrayList<>();
		queryFile = line.getOptionValue("queries", queryFile);//"");   sample_query.queryset STAR_ALL_workload
		parseQueries();
		end = System.nanoTime();
		exec = end - start;
		inSeconds = (double)exec / 1_000_000_000.0;
		System.out.println("\n---> Response to all queries took : "+ exec + " nanoseconds which is "+inSeconds+" in seconds");

	}

	// ========================================================================

	
	 // Traite chaque requête lue dans {@link #queryFile} avec {@link #processAQuery(ParsedQuery)}.
	 
	private static void parseQueries() throws FileNotFoundException, IOException {
		System.out.println("Génération du fichier des résultats en cours ...\n");
		try (Stream<String> lineStream = Files.lines(Paths.get(queryFile))) {
			SPARQLParser sparqlParser = new SPARQLParser();
			Iterator<String> lineIterator = lineStream.iterator();

			StringBuilder queryString = new StringBuilder();

			while (lineIterator.hasNext())			 
			{
				String line = lineIterator.next();
				queryString.append(line+"\n");//.trim();
				if (line.trim().endsWith("}")) {				
					ParsedQuery query = sparqlParser.parseQuery(queryString.toString(), baseURI);
					// System.out.println("ehehehhehe "+Calculs.queries.size()+" "+counter);
					processAQuery(query,queryString.toString()); // Traitement de la requête, à adapter/réécrire pour votre programme
					queryString.setLength(0); // Reset le buffer de la requête en chaine vide
				}
			}
		}
		System.out.println("---> fichier 'results.md' généré (dans le dossier 'Queries_results') ayant comme contenu les requetes et leur résultat.\n");	
	}
	
	
	//  Traite chaque triple lu dans {@link #dataFile} avec {@link MainRDFHandler}.
	 
	private static void parseData() throws FileNotFoundException, IOException {

		try (Reader dataReader = new FileReader(dataFile)) {
			// On va parser des données au format ntriples
			RDFParser rdfParser = Rio.createParser(RDFFormat.NTRIPLES);

			// On utilise notre implémentation de handler
			rdfParser.setRDFHandler(new MainRDFHandler());

			// Parsing et traitement de chaque triple par le handler
			rdfParser.parse(dataReader, baseURI);
			
			Dictionnaire.displaying_dictionary(dataFile);
		}
	}

	private static Options configParameters() {

		final Option helpFileOption = Option.builder("h").longOpt("help").desc("affiche le menu d'aide").build();

		final Option queriesOption = Option.builder("queries").longOpt("queries").hasArg(true)
				.argName("/chemin/vers/dossier/requetes").desc("Le chemin vers les queries").required(false).build();

		final Option dataOption = Option.builder("data").longOpt("data").hasArg(true)
				.argName("/chemin/vers/fichier/donnees").desc("Le chemin vers les donnees").required(false).build();

		final Option outputOption = Option.builder("output").longOpt("output").hasArg(true)
				.argName("/chemin/vers/dossier/sortie").desc("Le chemin vers le dossier de sortie").required(false)
				.build();

		// crée une liste d'options
		final Options options = new Options();
		options.addOption(queriesOption);
		options.addOption(dataOption);
		options.addOption(outputOption);
		options.addOption(helpFileOption);

		return options;
	}
}
